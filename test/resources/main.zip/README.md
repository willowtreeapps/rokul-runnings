# BouncingLogoScreensaver
Display your square logo image in a beautiful way. To implement this 
component, enter the ukor.properties.yaml file and modify your targeted 
flavor in the following way:

flavors:
  main:
    src:
      - main
      - 'BouncingLogoScreensaver'

Doing this, alongside entering your companys images in the 
BouncingLogoScreensaver/images folder and modifying the image file 
name in the BouncingLogoScreensaver.xml file will make the 
screensaver channel functional in your application.